e-Registry Portal — Android APK project

WHAT IS INCLUDED
- app/src/main/assets/index.html: your portal, prepared for mobile WebView.
- MainActivity.kt: Android WebView wrapper with immersive full-screen mode.
- AndroidManifest.xml and Gradle files: Android Studio project setup.

BUILD APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio choose Open, then select the extracted eRegistry_Android_APK_Project folder.
4. Wait for Gradle sync to finish.
5. For a test APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location when the build finishes.

FULL-SCREEN NOTE
The Android app wrapper requests immersive sticky mode: status bar and navigation bar are hidden while the app is active. Android may reveal system bars temporarily after an edge swipe. This ZIP is an Android Studio project, not a precompiled APK.

NETWORK NOTE
The portal currently references external web fonts. Internet permission is included so those fonts can load. The main HTML itself is bundled locally in the app.
